# test_002 · 胶子融合产生顶夸克对的并发度

输入为 test_002 的压缩 LHE，另用 MadGraph 输出的平均自旋密度矩阵做独立核对。该运行使用质子束，每束 6500 GeV，硬过程为 g g > t t~，顶夸克质量 173 GeV，PDF 标签 nn23nlo。50,000 个事件的名义权重相同。LHE 的 MGDensity 头部给出的螺旋度顺序为 ++、+-、-+、--，helicity_direction 为 [6]，momenta_boost 实际记录为 [0]。本分析直接用四动量重建散射角和速度，只对并发度作逐事件理论比较。

## 复现

解压后在装有 NumPy 和 Matplotlib 的 Python 3 环境运行，按本地文件名调整路径。

```bash
python gg_phase.py 'unweighted_events.lhe(1).gz' \
  --average 'Average_density_matrix_unweighted_events(1).txt' \
  --bins 40 --out reproduced
```

## 图与数据

- test_002_gg_phase.png 和 .pdf 为同一张对照图。左图为解析函数，右图为每格内先逐事件计算并发度、再取算术平均的结果。空格为白色。两条黑线为理论零并发度区域的上下边界。
- 横轴 x = 2θ_fold/π。θ_fold = arccos(|cos θ*|)，θ* 为 ttbar 质心系中顶夸克与束轴的夹角。纵轴 β = sqrt(1 − 4 mt²/Mtt²)。
- events.csv.gz 含原始 LHE 事件序号（从 1 起）、顶夸克对不变质量、折叠角坐标、速度、模拟并发度、解析并发度和两者的差。
- bins.csv 的每一行是一格。mean_C_MG 是模拟均值。mean_C_LO_at_events 在同一批事件的运动学点计算解析值后取均值。C_LO_at_center 仅在格子中心计算，与前者可以有有限分箱差异。mean_delta 是前两种均值的带符号差。
- stats.json 给出精度核对和覆盖统计。positive_C 采用数值判据 C > 1e-10。全部矩阵取平均后再求并发度与逐事件并发度的平均是两个不同的物理量。

理论来源：L. Durupt、F. Maltoni、O. Mattelaer，Automated computation of spin-density matrices and quantum observables for collider physics，arXiv:2510.17730v1，第 3.1 节式 (15)–(20) 与图 3。https://arxiv.org/html/2510.17730v1
