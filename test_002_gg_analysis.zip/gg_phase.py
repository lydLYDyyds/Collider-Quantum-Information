"""Reproduce the test_002 phase map with Python 3, numpy and matplotlib.
Run: python gg_phase.py INPUT.lhe.gz --out results --bins 40
Optionally pass --average FILE to cross-check the separate MadGraph matrix.
"""
import argparse
import ast
import gzip
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read_events(path):
    """Read this pure collinear LO gg > t tbar sample; reject other topologies."""
    masses, betas, angles, weights, triangles = [], [], [], [], []
    with (gzip.open if path.suffix == ".gz" else open)(path, "rb") as f:
        for _, elem in ET.iterparse(f, events=("end",)):
            if elem.tag == "MGDensity":
                fields = dict(line.split(" = ", 1) for line in elem.text.strip().splitlines())
                assert ast.literal_eval(fields["allowed_helicities"]) == [1,1,1,-1,-1,1,-1,-1]
                assert ast.literal_eval(fields["particle_in_density_matrix"])[0] == [6,-6]
                assert fields["matrix_normalisation"] == "True"
            if elem.tag != "event":
                continue
            lines = elem.text.strip().splitlines()
            count, _, weight, *_ = lines[0].split()
            assert int(count) == 4
            particles = [line.split() for line in lines[1:5]]
            assert sorted((int(p[0]),int(p[1])) for p in particles) == [(-6,1),(6,1),(21,-1),(21,-1)]
            top, antitop = (next(p for p in particles if int(p[0]) == pid) for pid in (6,-6))
            px, py, pz, energy, mt = map(float, top[6:11])
            ax, ay, az, ae = map(float, antitop[6:10])
            assert np.hypot(px+ax, py+ay) < 1e-5
            # Pure longitudinal boost into the pair rest frame. Either beam
            # gives the same folded angle because the incoming gluons are identical.
            total_e, total_z = energy+ae, pz+az
            mass = np.sqrt((total_e-total_z)*(total_e+total_z))
            pz_star = (total_e*pz-total_z*energy)/mass
            angle = np.arctan2(np.hypot(px, py), abs(pz_star))
            beta = np.sqrt(1-(2*mt/mass)**2)
            packed = [complex(v) for v in elem.find("density").text.split()]
            assert len(packed) == 10
            triangles.append(packed)
            masses.append(mass)
            betas.append(beta)
            angles.append(angle)
            weights.append(float(weight))
            elem.clear()
    assert len(set(weights)) == 1 and weights[0] > 0
    row, col = np.triu_indices(4)  # Transpose upper row order to lower column order.
    matrices = np.zeros((len(angles),4,4), dtype=complex)
    matrices[:,col,row] = triangles
    matrices[:,row,col] = np.conj(triangles)
    assert np.allclose(matrices, matrices.conj().swapaxes(1,2), atol=1e-12, rtol=0)
    assert np.max(abs(np.trace(matrices,axis1=1,axis2=2)-1)) < 1e-9
    return np.array(masses), np.array(betas), np.array(angles), matrices


def concurrence(rho):
    """Wootters' formula via singular values of sqrt(rho) S sqrt(rho)*."""
    val, vec = np.linalg.eigh(rho)
    assert val.min() >= -1e-10
    root = (vec*np.sqrt(np.maximum(val,0))[...,None,:]) @ vec.conj().swapaxes(-1,-2)
    sy = np.array([[0,-1j],[1j,0]])
    singular = np.linalg.svd(root @ np.kron(sy,sy) @ root.conj(), compute_uv=False)
    return np.maximum(singular[...,0] - singular[...,1:].sum(axis=-1), 0)


def theory(beta, angle):
    """Durupt et al., arXiv:2510.17730v1, Eq. (18)."""
    b, s = beta**2, np.sin(angle)**2
    term = b**2 * (1+s**2)
    numerator = np.where(b*(1+s)<1, 1-2*b*(1+s)+term, term-1)
    return np.maximum(0, numerator/(1+2*b*s-term))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("lhe", type=Path)
    parser.add_argument("--average", type=Path)
    parser.add_argument("--bins", type=int, default=40)
    parser.add_argument("--out", type=Path, default=Path("."))
    args = parser.parse_args()
    out = args.out
    out.mkdir(exist_ok=True, parents=True)
    mass, beta, angle, rho = read_events(args.lhe)
    x = 2*angle/np.pi
    sim, lo = concurrence(rho), theory(beta, angle)
    delta = sim-lo
    edges = np.linspace(0,1,args.bins+1)
    def hist(weights=None):
        return np.histogram2d(beta,x,bins=(edges,edges),weights=weights)[0]
    counts = hist()
    assert int(counts.sum()) == len(x)
    def mean(values):
        return np.divide(hist(values),counts,out=np.full_like(counts,np.nan),where=counts>0)
    observed, matched, residual = mean(sim), mean(lo), mean(delta)
    X, B = np.meshgrid((edges[1:]+edges[:-1])/2,(edges[1:]+edges[:-1])/2)
    center = theory(B, X*np.pi/2)
    np.savetxt(out/"bins.csv",np.stack([X,B,counts,observed,matched,center,residual],axis=-1).reshape(-1,7),
               header="x_center,beta_center,events,mean_C_MG,mean_C_LO_at_events,C_LO_at_center,mean_delta",delimiter=",",comments="")
    np.savetxt(out/"events.csv.gz",np.column_stack([np.arange(1,len(x)+1),mass,x,beta,sim,lo,delta]),
               header="LHE_event,Mtt_GeV,x_folded,beta,C_MG,C_LO,delta",delimiter=",",comments="",fmt=["%d"]+["%.15g"]*6)
    stats = dict(events=len(x),bins=args.bins,occupied=int((counts>0).sum()),
                 positive_C=int((sim>1e-10).sum()),mean_C_MG=sim.mean(),mean_C_LO=lo.mean(),
                 max_abs_delta=abs(delta).max(),mean_abs_delta=abs(delta).mean(),
                 max_abs_bin_mean_delta=np.nanmax(abs(residual)),max_abs_bin_center_difference=np.nanmax(abs(observed-center)),
                 C_of_mean_matrix=float(concurrence(rho.mean(axis=0))),beta_range=[beta.min(),beta.max()])
    if args.average:
        values = re.findall(r"np\.complex128\(([^)]+)\)",args.average.read_text())
        reference = np.array(list(map(complex,values))).reshape(4,4)
        stats["max_mean_rho_element_difference"] = abs(rho.mean(axis=0)-reference).max()
    (out/"stats.json").write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats, indent=2))
    fig, axes = plt.subplots(1,2,figsize=(10.3,5.35),layout="constrained")
    colors = plt.get_cmap("turbo").copy()
    colors.set_bad("#ffffff")
    fine = (np.arange(600)+0.5)/600
    fx, fb = np.meshgrid(fine,fine)
    axes[0].imshow(theory(fb,fx*np.pi/2),extent=(0,1,0,1),origin="lower",interpolation="nearest",cmap=colors,vmin=0,vmax=1)
    im = axes[1].pcolormesh(edges,edges,np.ma.masked_invalid(observed),cmap=colors,vmin=0,vmax=1,rasterized=True)
    curve = np.linspace(0,1,600)
    sin = np.sin(curve*np.pi/2)
    for ax, title in zip(axes,("LO QCD prediction","MadGraph event matrices")):
        ax.plot(curve,np.sqrt((1+sin**2-np.sqrt(2)*sin)/(1+sin**4)),color="#12151b",lw=1)
        ax.plot(curve,(1+sin**4)**(-0.25),color="#12151b",lw=1)
        ax.set(xlim=(0,1),ylim=(0,1),aspect="equal",xlabel=r"$2\theta_{\rm fold}/\pi$",title=title)
    axes[0].set_ylabel(r"$\beta$")
    fig.colorbar(im,ax=axes,shrink=.76,pad=.025,label="Concurrence")
    fig.suptitle(r"$gg\rightarrow t\bar{t}$ spin entanglement at 13 TeV",fontsize=17)
    fig.supxlabel(f"{len(x):,} unweighted events   |   {args.bins} × {args.bins} bins   |   white: no events   |   curves: LO separability boundaries",fontsize=10)
    for ext in ("png","pdf"):
        fig.savefig(out/f"test_002_gg_phase.{ext}",dpi=220)
    plt.close(fig)


if __name__ == "__main__":
    main()
